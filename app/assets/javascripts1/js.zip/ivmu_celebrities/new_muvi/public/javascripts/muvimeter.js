$.get('/movies/i-am/muvimeter', function(data) {
  MyXssMagic.serverResponse(['Dr Nic', 'Banjo', 'Angus']);
})
